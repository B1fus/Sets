﻿#include <iostream>
#include <string>
#include "Set.h"

void fill_set_cin_string(Set<char>& set) {
	std::string str;
	std::getline(std::cin, str);
	for (char& i : str) {
		set.insert(i);
	}
}

int main()
{
	Set<char> a,b,c, res, universum;
	std::string str;

	fill_set_cin_string(a);
	a.print();
	std::cout << "\n";
	fill_set_cin_string(b);
	b.print();
	std::cout << "\n";
	fill_set_cin_string(c);
	c.print();
	std::cout << "\n\n";

	universum = a | b | c;

	universum.print();
	std::cout << "\n";

	bool* mas1 = a.get_characteristic_vector(universum);
	for (int i = 0; i < universum.size(); i++) {
		std::cout << mas1[i] << " ";
	}
	std::cout << "\n";
	bool* mas2 = b.get_characteristic_vector(universum);
	for (int i = 0; i < universum.size(); i++) {
		std::cout << mas2[i] << " ";
	}
	std::cout << "\n";
	bool* mas3 = c.get_characteristic_vector(universum);
	for (int i = 0; i < universum.size(); i++) {
		std::cout << mas3[i] << " ";
	}
	std::cout << "\n";

	int temp = 0;
	for (int i = 0; i < universum.size(); i++) {
		temp = mas1[i] - mas3[i] - mas2[i] <= 0 ? 0 : 1;
		std::cout << temp << " ";
	}
	std::cout << "\n";
	system("Pause");
}
